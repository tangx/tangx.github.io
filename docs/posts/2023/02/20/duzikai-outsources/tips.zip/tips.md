
# 独自开 tips

私活平台推广拉人， 注册做题审核通过后，「支付宝打款50」，
注册链接： https://sourl.cn/UjLULJ
注册之后， 可以自己尝试先做题。 我不清楚是不是每个人的题目都一样的， 有问题可以先发在群里面。


## 1. 工具准备

我用的是 vscode， 其他工具自己选择。

1. 下载 vscode
2. vscode 安装 vue 插件 (可选， 基本就提供一个高亮和格式化) : https://marketplace.visualstudio.com/items?itemName=Vue.volar


## 2. 下载题目

1. 登陆 duzikai 系统， 下载 **前端认证题**

2. 解压后分两层目录
  + 说明在第一层
  + 题目在第二层

```
duzikai_written_examination_certification_20230213
 |- 001_center_data_lite_mod_interview_exam_easy
```

3. 使用 vscode 打开 `001_center_data_lite_mod_interview_exam_easy` 项目

4. 使用命令设置淘宝源

```bash
yarn config set registry https://registry.npm.taobao.org/
npm config set registry https://registry.npm.taobao.org/
```

5. 「可选」 使用 `git` 管理项目， 方便改错之后回滚

**1. 初始化项目**
```bash
git init
```

**2. 添加更改**

```bash
git add .
git commit -m 'init'
```

**3. 回滚更改**

```bash
git checkout .
```

## 3. 做题

### 3.1 几个关键文件、

认证阅读说明， 第一层目录的， **对外接口说明.md**。 剩下的就是展示调整了。

1. `vue.config.js` 修改代理
2. `warehouse.js` 修改请求路径
3. `src/.../warehouse/index.js` **修改请求内容** 和 **表格展示字段**。 要求和 **墨刀** 一直。 

**提示： 适当写一点注释， 可能通过率会高一点，（我猜的）**。


## 4. 打包上传

1. 删除 git 历史记录和前端依赖包

```bash
rm -rf .git
rm -rf node_modules
```


2. 登陆平台， 下载 「前端工具包」, 并解压。 默认名字为 `duzikai_-front_-end_-core_-version_101`


3. 复制 001_xxx 功能目录到前端工具包， **并且重命名** 为 `000_interview_exam`

**举个例子， 根据自己实际情况操作**
```bash
# 
cp -a 001_center_data_lite_mod_interview_exam_easy duzikai_-front_-end_-core_-version_101/000_interview_exam
```

4. 压缩前端工具包， `duzikai_-front_-end_-core_-version_101.zip`

5. 登陆平台， 上传提交

